// ==UserScript==
// @name         02. ATOM Index Frame | V1.4
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Ajusta los tamaños de BaseTable y marco exterior
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {

    // ==================================================
    // AJUSTES
    // ==================================================

    const WIDTH     = 550; // Ancho BaseTable
    const HEIGHT    = 204; // Alto BaseTable
    const MAX_WIDTH = 550; // Ancho contenedor AR
    const HDR_WIDTH = 540; // Ancho TABLE HDR interior

    const FRAME_WIDTH  = 850; // Ancho marco exterior



    // ==================================================
    // APLICAR
    // ==================================================

    function aplicar() {

        const baseTable = document.querySelector("table.BaseTable");

        if (!baseTable) {
            setTimeout(aplicar, 500);
            return;
        }

        const baseInner = baseTable.parentElement;
        const baseOuter = baseInner?.parentElement;
        const tableInner = baseOuter?.parentElement;


        // ==========================================
        // 1. WIDTH + HEIGHT
        // ==========================================

        if (baseInner) {
            baseInner.style.setProperty("width", `${WIDTH}px`, "important");
            baseInner.style.setProperty("max-width", `${WIDTH}px`, "important");
            baseInner.style.setProperty("height", `${HEIGHT}px`, "important");
            baseInner.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }

        if (baseOuter) {
            baseOuter.style.setProperty("width", `${WIDTH}px`, "important");
            baseOuter.style.setProperty("max-width", `${WIDTH}px`, "important");
            baseOuter.style.setProperty("height", `${HEIGHT}px`, "important");
            baseOuter.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }

        if (tableInner) {
            tableInner.style.setProperty("width", `${WIDTH}px`, "important");
            tableInner.style.setProperty("max-width", `${WIDTH}px`, "important");
            tableInner.style.setProperty("height", `${HEIGHT}px`, "important");
            tableInner.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }


        // ==========================================
        // 2. TABLE HDR
        // ==========================================

        const tableHdr = tableInner
            ? tableInner.parentElement?.querySelector("table.TableHdr")
            : null;

        if (tableHdr) {
            tableHdr.style.setProperty(
                "width",
                `${HDR_WIDTH}px`,
                "important"
            );

            tableHdr.style.setProperty(
                "max-width",
                `${HDR_WIDTH}px`,
                "important"
            );
        }


        // ==========================================
        // 3. CONTENEDOR AR
        // ==========================================

        const arContainer = document.querySelector(
            ".arfid301444200.ardbnz2TH_ConsolidateTable1"
        );

        if (arContainer) {
            arContainer.style.setProperty(
                "max-width",
                `${MAX_WIDTH}px`,
                "important"
            );
        }


        // ==========================================
        // 4. FORM CONTAINER
        // ==========================================

        const formContainer = document.querySelector("#FormContainer");

        if (formContainer) {

            formContainer.style.setProperty(
                "width",
                `${FRAME_WIDTH}px`,
                "important"
            );

            formContainer.style.setProperty(
                "max-width",
                `${FRAME_WIDTH}px`,
                "important"
            );

            formContainer.style.setProperty(
                "height",
                `${FRAME_HEIGHT}px`,
                "important"
            );

            formContainer.style.setProperty(
                "max-height",
                `${FRAME_HEIGHT}px`,
                "important"
            );

            console.log("[ATOM] FormContainer aplicado:", {
                FRAME_WIDTH,
                FRAME_HEIGHT
            });
        }


        // ==========================================
        // 5. CONSOLA
        // ==========================================

        console.log("[ATOM] Tamaños aplicados:", {
            WIDTH,
            HEIGHT,
            MAX_WIDTH,
            HDR_WIDTH,
            FRAME_WIDTH,
            FRAME_HEIGHT
        });
    }


    // ==================================================
    // ESPERAR A QUE ATOM TERMINE DE CONSTRUIR LA VISTA
    // ==================================================

    setTimeout(aplicar, 3000);

})();