// ==UserScript==
// @name         ATOM | TEST ejecución
// @namespace    http://tampermonkey.net/
// @version      1.0
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

alert('ATOM USER.JS EJECUTADO');
