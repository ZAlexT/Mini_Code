// ==UserScript==
// @name         ATOM | Forzar tamaño ConsolidateTable
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Fuerza los tamaños de WIN_2_301444200
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
const TABLA_ID = 'WIN_2_301444200';

function aplicar() {
    const tabla = document.getElementById(TABLA_ID);

    if (!tabla) return;

    // WIN_2_301444200 → 700 × 204
    tabla.style.width = '700px';
    tabla.style.height = '204px';

    // TableInner → 700 × 204
    tabla.querySelectorAll('.TableInner').forEach(el => {
        el.style.width = '700px';
        el.style.height = '204px';
    });

    // BaseTableOuter → 700 × 204
    tabla.querySelectorAll('.BaseTableOuter').forEach(el => {
        el.style.width = '700px';
        el.style.height = '204px';
    });

    // TableHdr → 550px
    tabla.querySelectorAll('table.TableHdr').forEach(el => {
        el.style.width = '550px';
    });
}

// Aplicar repetidamente porque ATOM puede crear/recalcular la tabla
const intervalo = setInterval(aplicar, 100);

// Parar después de 10 segundos
setTimeout(() => {
    clearInterval(intervalo);
}, 10000);
```

})();
