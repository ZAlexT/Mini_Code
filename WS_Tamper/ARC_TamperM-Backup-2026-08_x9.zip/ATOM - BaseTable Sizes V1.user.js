// ==UserScript==
// @name         ATOM | BaseTable Sizes V1
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Ajusta los tamaños de BaseTable
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {

    // ==================================================
    // AJUSTES
    // ==================================================

    const WIDTH     = 540;
    const HEIGHT    = 204;
    const HDR_WIDTH = 542;


    // ==================================================
    // APLICAR
    // ==================================================

    function aplicar() {

        const baseTable = document.querySelector("table.BaseTable");

        if (!baseTable) {
            setTimeout(aplicar, 500);
            return;
        }

        const baseInner = baseTable.parentElement;
        const baseOuter = baseInner?.parentElement;
        const tableInner = baseOuter?.parentElement;

        const tableHdr = tableInner
            ? tableInner.parentElement?.querySelector("table.TableHdr")
            : null;


        // BaseTableInner
        if (baseInner) {
            baseInner.style.setProperty("width", `${WIDTH}px`, "important");
            baseInner.style.setProperty("max-width", `${WIDTH}px`, "important");
            baseInner.style.setProperty("height", `${HEIGHT}px`, "important");
            baseInner.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }


        // BaseTableOuter
        if (baseOuter) {
            baseOuter.style.setProperty("width", `${WIDTH}px`, "important");
            baseOuter.style.setProperty("max-width", `${WIDTH}px`, "important");
            baseOuter.style.setProperty("height", `${HEIGHT}px`, "important");
            baseOuter.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }


        // TableInner
        if (tableInner) {
            tableInner.style.setProperty("width", `${WIDTH}px`, "important");
            tableInner.style.setProperty("max-width", `${WIDTH}px`, "important");
            tableInner.style.setProperty("height", `${HEIGHT}px`, "important");
            tableInner.style.setProperty("max-height", `${HEIGHT}px`, "important");
        }


        // TableHdr
        if (tableHdr) {
            tableHdr.style.setProperty("width", `${HDR_WIDTH}px`, "important");
            tableHdr.style.setProperty("max-width", `${HDR_WIDTH}px`, "important");
        }

    }


    // Esperar a que ATOM termine de construir la tabla
    setTimeout(aplicar, 3000);

})();