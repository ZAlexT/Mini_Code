// ==UserScript==
// @name         ATOM | TEST BaseTable 700x204 + HDR 550
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Fuerza BaseTable a 700x204 y TableHdr a 550
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {

    function aplicar() {

        const baseTable = document.querySelector("table.BaseTable");

        if (!baseTable) {
            console.log("[ATOM TEST] BaseTable no encontrada");
            setTimeout(aplicar, 500);
            return;
        }

        const baseInner = baseTable.parentElement;
        const baseOuter = baseInner?.parentElement;
        const tableInner = baseOuter?.parentElement;

        const tableHdr = tableInner
            ? tableInner.parentElement?.querySelector("table.TableHdr")
            : null;

        console.log("[ATOM TEST] BaseTable encontrada");
        console.log("[ATOM TEST] BaseTableInner:", baseInner);
        console.log("[ATOM TEST] BaseTableOuter:", baseOuter);
        console.log("[ATOM TEST] TableInner:", tableInner);
        console.log("[ATOM TEST] TableHdr:", tableHdr);

        // BaseTableInner
        if (baseInner) {
            baseInner.style.setProperty("width", "700px", "important");
            baseInner.style.setProperty("max-width", "700px", "important");
            baseInner.style.setProperty("height", "204px", "important");
            baseInner.style.setProperty("max-height", "204px", "important");
        }

        // BaseTableOuter
        if (baseOuter) {
            baseOuter.style.setProperty("width", "700px", "important");
            baseOuter.style.setProperty("max-width", "700px", "important");
            baseOuter.style.setProperty("height", "204px", "important");
            baseOuter.style.setProperty("max-height", "204px", "important");
        }

        // TableInner
        if (tableInner) {
            tableInner.style.setProperty("width", "700px", "important");
            tableInner.style.setProperty("max-width", "700px", "important");
            tableInner.style.setProperty("height", "204px", "important");
            tableInner.style.setProperty("max-height", "204px", "important");
        }

        // TableHdr
        if (tableHdr) {
            tableHdr.style.setProperty("width", "550px", "important");
            tableHdr.style.setProperty("max-width", "550px", "important");
        }

        console.log("[ATOM TEST] 700 / 204 / 550 APLICADOS");
    }

    setTimeout(aplicar, 3000);

})();