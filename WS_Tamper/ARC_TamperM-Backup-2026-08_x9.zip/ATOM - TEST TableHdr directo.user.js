// ==UserScript==
// @name         ATOM | TEST TableHdr directo
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Test directo de TableHdr
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
setTimeout(function () {

    const elementos = document.getElementsByClassName('TableHdr');

    alert('TableHdr encontrados: ' + elementos.length);

    for (let i = 0; i < elementos.length; i++) {

        elementos[i].setAttribute(
            'style',
            'width: 300px;'
        );

    }

}, 15000);
```

})();
