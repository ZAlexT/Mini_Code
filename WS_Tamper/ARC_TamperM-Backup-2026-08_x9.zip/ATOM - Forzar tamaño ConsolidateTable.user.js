// ==UserScript==
// @name         ATOM | Forzar tamaño ConsolidateTable
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Fuerza 700x204 en ConsolidateTable1 y sus contenedores
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
const PADRE_ID = 'WIN_2_304059300';
const TABLA_ID = 'WIN_2_301444200';

const ANCHO = '700px';
const ALTO = '204px';

function forzarTamano(el) {
    if (!el) return;

    el.style.setProperty('width', ANCHO, 'important');
    el.style.setProperty('max-width', ANCHO, 'important');

    el.style.setProperty('height', ALTO, 'important');
    el.style.setProperty('max-height', ALTO, 'important');
}

function aplicar() {

    const padre = document.getElementById(PADRE_ID);
    const tabla = document.getElementById(TABLA_ID);

    if (!tabla) return;

    // Padre real de la tabla
    forzarTamano(padre);

    // WIN_2_301444200
    forzarTamano(tabla);

    // Elementos que controlan el tamaño interno
    tabla.querySelectorAll(
        '.TableHdr,' +
        '.TableHdr table,' +
        '.TableInner,' +
        '.BaseTableOuter,' +
        '.BaseTableColHeaders,' +
        '.BaseTableInner,' +
        '#T301444200'
    ).forEach(forzarTamano);
}

// Aplicación inicial
aplicar();

// ATOM puede crear/recrear/recalcular los elementos
const observer = new MutationObserver(() => {
    aplicar();
});

observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style']
});
```

})();
