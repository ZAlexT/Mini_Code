// ==UserScript==
// @name         01. ARC Colorizer | V1.9 002 Names
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Colorear Estados en ARC | Estavos VBox + Detalles + Órgano de Prueba + Tipo + SI
// @author       AL
// @match        https://sc.vistes.justicia.intranet.gencat.cat/*
// @run-at       document-end
// @grant        none
// ==/UserScript==


/*
==========================================================
  01. ARC Colorizer | V1.9 - Colorear Textos
==========================================================

DESCRIPCIÓN:
Este UserScript colorea y anima textos dentro del entorno ARC.
Actúa sobre:

- Estados generales (VBox + Session)
- Señal institucional VBox
- Bloque específico "Órgano de Prueba"
- Tipos concretos dentro del bloque
- Elementos dinámicos recargados vía MutationObserver

Permite aplicar:
- Color
- Negrita
- Parpadeo (blink)
- Efecto Glow

El script está preparado para ampliaciones futuras mediante
objetos configurables y selectores específicos.

----------------------------------------------------------
ÍNDICE DE BLOQUES Y ESTRUCTURA INTERNA
----------------------------------------------------------

1. ESTILOS Y ANIMACIONES
   - @keyframes arcBlink
   - @keyframes arcGlow
   - Clases:
       .arc-blink
       .arc-glow

2. ESTADOS GENERALES
   - VBox States
   - Session States
   - Señal Institucional
   - Configuración por objeto:
       { color, bold, blink, glow }

3. BLOQUE ÓRGANO DE PRUEBA (ESPECÍFICO)
   - Configuración por texto clave
   - Selector CSS asociado
   - Propiedades:
       { selector, color, bold, glow }
   - Preparado para ampliar con nuevas entradas

4. NORMALIZADOR
   - Normalizar(texto)
   - Conversión a minúsculas
   - Limpieza de espacios
   - Comparación robusta mediante includes()

5. PROCESADO DE ESTADOS
   - QuerySelector múltiple:
       zona-lineadatos
       celdaRegistro
       celdaRegistroLinea
       ARC_textoValor
   - Aplicación dinámica de estilos
   - Toggle inteligente de clases animadas

6. PROCESADO BLOQUE ÓRGANO
   - Búsqueda por selector específico
   - Aplicación selectiva de color y efectos
   - No interfiere con estados generales

7. OBSERVER DINÁMICO
   - MutationObserver sobre document.body
   - Reaplicación automática tras recargas internas
   - Debounce con setTimeout (250ms)

----------------------------------------------------------
NOTAS GENERALES
----------------------------------------------------------

- La coincidencia se realiza por texto parcial (includes).
- El sistema está preparado para:
    - Añadir nuevos estados fácilmente.
    - Añadir nuevos bloques específicos.
    - Separar en el futuro Includes independientes.
- No modifica estructura DOM, solo estilos.
- No interfiere con eventos internos de ARC.

==========================================================
*/

(function() {
    'use strict';

    //-------------------------------------------------------------
    // ESTILOS (Blink + Glow)
    //-------------------------------------------------------------
    const style = document.createElement("style");
    style.textContent = `
        @keyframes arcBlink {
              0% { opacity: 1; }
             50% { opacity: 0.35; }
            100% { opacity: 1; }
        }
        .arc-blink { animation: arcBlink 1.5s infinite; }

        @keyframes arcGlow {
            0%   { text-shadow: 0 0 4px currentColor; }
            50%  { text-shadow: 0 0 12px currentColor; }
            100% { text-shadow: 0 0 4px currentColor; }
        }
        .arc-glow { animation: arcGlow 1.8s infinite ease-in-out; }
    `;
    document.head.appendChild(style);

    //-------------------------------------------------------------
    // 01 - ESTADOS GENERALES (igual que ya tienes)
    //-------------------------------------------------------------
    const estados = {

        'En Curso':       { color: '#09ff09', bold: true, glow: true },
        'Finalizada':     { color: 'green', bold: true },
        'Suspendida':     { color: 'blue' },
        'Anulada':        { color: 'red', bold: true },
        'No celebrada':   { color: 'violet' }

        // 👉 añadir más aquí
    };

    //-------------------------------------------------------------
    // 02 - BLOQUE ÓRGANO (A + B)
    //-------------------------------------------------------------
    const bloqueOrgano = {

        'Órgano de Prueba': {
            selector: '.titIdenWeb_A, .titIdenWeb_B',
            color: '#00bfff',
            bold: true
        },

        'Apremio': {
            selector: '.txt2IdenWeb_A, .txt2IdenWeb_B',
            color: 'red',
            bold: true,
            glow: true
        }

        // 👉 añadir más subbloques aquí
    };

    //-------------------------------------------------------------
    // 03 - COLUMNAS (Nombre + Ubicación)
    //-------------------------------------------------------------
    const columnasConfig = {

        // Columna 1 → Nombre
        1: [
            { texto: 'Sala de vistes 201 Planta 2', color: '#00bfff', bold: true }
            // 👉 añadir más nombres aquí
        ],

        // Columna 2 → Ubicación
        2: [
            { texto: 'BARCELONA', color: 'orange', bold: true }
            // 👉 añadir más ubicaciones aquí
        ]

        // FUTURO:
        // 3 → Estado
        // 4 → Alarmas
    };

    //-------------------------------------------------------------
    // Normalizador
    //-------------------------------------------------------------
    function normalizar(texto) {
        return texto.toLowerCase().replace(/\s+/g, ' ').trim();
    }

    const estadosNormalizados = Object.entries(estados).map(([clave, config]) => ({
        clave: normalizar(clave),
        config
    }));

    //-------------------------------------------------------------
    // 01 - ESTADOS GENERALES
    //-------------------------------------------------------------
    function colorearTextos() {

        const elementos = document.querySelectorAll(
            'div.zona-lineadatos div.celdaRegistro, div.zona-lineadatos div.celdaRegistroLinea, .ARC_textoValor .valorT2'
        );

        elementos.forEach(el => {

            const texto = normalizar(el.textContent);
            if (!texto) return;

            for (const estado of estadosNormalizados) {

                if (texto.includes(estado.clave)) {

                    el.style.color = estado.config.color || '';
                    el.style.fontWeight = estado.config.bold ? 'bold' : '';

                    el.classList.toggle('arc-blink', !!estado.config.blink);
                    el.classList.toggle('arc-glow', !!estado.config.glow);

                    return;
                }
            }
        });
    }

    //-------------------------------------------------------------
    // 02 - BLOQUE ÓRGANO
    //-------------------------------------------------------------
    function colorearBloqueOrgano() {

        Object.entries(bloqueOrgano).forEach(([textoClave, config]) => {

            const elementos = document.querySelectorAll(config.selector);

            elementos.forEach(el => {

                if (normalizar(el.textContent).includes(normalizar(textoClave))) {

                    el.style.color = config.color || '';
                    el.style.fontWeight = config.bold ? 'bold' : '';

                    el.classList.toggle('arc-glow', !!config.glow);
                }
            });
        });
    }

    //-------------------------------------------------------------
    // 03 - COLUMNAS CONTROLADAS (NUEVO)
    //-------------------------------------------------------------
    function colorearColumnas() {

        const filas = document.querySelectorAll('.zona-lineadatos');

        filas.forEach(fila => {

            const columnas = fila.querySelectorAll('.celdaRegistro, .celdaRegistroLinea');

            Object.entries(columnasConfig).forEach(([index, reglas]) => {

                const col = columnas[index];
                if (!col) return;

                const texto = normalizar(col.textContent);

                // FILTROS (evita basura)
                if (!texto || texto.length < 3) return;
                if (/^\d+$/.test(texto)) return;

                reglas.forEach(regla => {

                    if (texto.includes(normalizar(regla.texto))) {

                        if (regla.color) col.style.color = regla.color;
                        if (regla.bold) col.style.fontWeight = 'bold';

                        if (regla.glow) {
                            col.style.textShadow = `
                                0 0 4px ${regla.color},
                                0 0 8px ${regla.color}
                            `;
                        }
                    }
                });
            });
        });
    }

    //-------------------------------------------------------------
    // CALL INICIAL
    //-------------------------------------------------------------
    function ejecutarColorizer() {
        colorearTextos();
        colorearBloqueOrgano();
        colorearColumnas(); // 👈 NUEVO
    }

    ejecutarColorizer();

    //-------------------------------------------------------------
    // OBSERVER (AUTO-REFRESH DOM)
    //-------------------------------------------------------------
    let timeout;
    const observer = new MutationObserver(() => {

        clearTimeout(timeout);

        timeout = setTimeout(() => {
            ejecutarColorizer(); // 👈 llama TODO
        }, 250);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

})();