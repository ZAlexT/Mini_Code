// ==UserScript==
// @name         ATOM | TEST localizar TableHdr
// @namespace    http://tampermonkey.net/
// @version      1.0
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
function buscarEnDocumento(doc, origen) {
    const elementos = doc.querySelectorAll('table.TableHdr');

    if (elementos.length) {
        alert(
            'ENCONTRADO\\n' +
            'Origen: ' + origen + '\\n' +
            'TableHdr: ' + elementos.length
        );

        elementos.forEach(el => {
            el.style.setProperty('width', '300px', 'important');
        });
    }

    // Buscar dentro de iframes
    const frames = doc.querySelectorAll('iframe');

    frames.forEach((frame, i) => {
        try {
            if (frame.contentDocument) {
                buscarEnDocumento(
                    frame.contentDocument,
                    origen + ' → iframe ' + i
                );
            }
        } catch (e) {
            console.log(
                '[ATOM TEST] iframe no accesible:',
                i
            );
        }
    });
}

setTimeout(() => {
    buscarEnDocumento(document, 'document principal');
}, 10000);
```

})();
