// ==UserScript==
// @name         ATOM | Forzar ConsolidateTable 700x204
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Fuerza el tamaño de ConsolidateTable1
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
const PADRE_ID = 'WIN_2_304059300';
const TABLA_ID = 'WIN_2_301444200';

const ANCHO = '700px';
const ALTO = '204px';

function forzar(el) {
    if (!el) return;

    el.style.setProperty('width', ANCHO, 'important');
    el.style.setProperty('max-width', ANCHO, 'important');

    el.style.setProperty('height', ALTO, 'important');
    el.style.setProperty('max-height', ALTO, 'important');
}

function aplicar() {

    const padre = document.getElementById(PADRE_ID);
    const tabla = document.getElementById(TABLA_ID);

    if (!tabla) return;

    // Padre
    forzar(padre);

    // Tabla 301444200
    forzar(tabla);

    // Elementos internos
    tabla.querySelectorAll(
        '.TableHdr,' +
        '.TableInner,' +
        '.BaseTableOuter,' +
        '.BaseTableColHeaders,' +
        '.BaseTableInner'
    ).forEach(forzar);
}

// Primera aplicación
aplicar();

// ATOM recalcula el tamaño después de crear la tabla.
// Reaplicamos durante los primeros segundos.
let contador = 0;

const intervalo = setInterval(() => {

    aplicar();

    contador++;

    if (contador >= 400) {
        clearInterval(intervalo);
    }

}, 100);
```

})();
