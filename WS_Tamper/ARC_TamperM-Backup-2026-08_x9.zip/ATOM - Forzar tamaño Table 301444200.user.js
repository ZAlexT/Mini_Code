// ==UserScript==
// @name         ATOM | Forzar tamaño Table 301444200
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Fuerza 700x204 en la tabla ConsolidateTable
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {
'use strict';

```
const TABLA_ID = 'WIN_2_301444200';
const ANCHO = '700px';
const ALTO = '204px';

function forzar(elemento) {
    if (!elemento) return;

    if (elemento.style.width !== ANCHO)
        elemento.style.setProperty('width', ANCHO, 'important');

    if (elemento.style.maxWidth !== ANCHO)
        elemento.style.setProperty('max-width', ANCHO, 'important');

    if (elemento.style.height !== ALTO)
        elemento.style.setProperty('height', ALTO, 'important');

    if (elemento.style.maxHeight !== ALTO)
        elemento.style.setProperty('max-height', ALTO, 'important');
}

function aplicar() {
    const tabla = document.getElementById(TABLA_ID);

    if (!tabla) return;

    forzar(tabla);

    tabla.querySelectorAll(
        '.TableInner, .BaseTableOuter, .BaseTableInner'
    ).forEach(forzar);
}

aplicar();

const observer = new MutationObserver(aplicar);

observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style']
});
```

})();
