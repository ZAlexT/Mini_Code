// ==UserScript==
// @name         02. ATOM Index by Aitor pt2
// @namespace    http://tampermonkey.net/
// @version      V8.0 112
// @description  ATOM | Colorize + Modern UI + Blink Modes + Fechas Dinámicas | Hover sin desplazamiento
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

/*
==========================================================
  02. Helix ATOM Index | V8.0 112

  CAMBIO PRINCIPAL:

  - La fila NO se desplaza.
  - La fila NO hace zoom.
  - La fila NO hace translate.
  - La fila NO cambia padding.
  - La fila NO cambia posición.
  - La fila NO tiene animación.
  - El hover de la fila SOLO cambia el color de fondo.
  - Las palabras pueden seguir teniendo sus efectos.
  - Los badges mantienen sus efectos.
  - Assigned / High mantienen blink + glow.
  - Fechas siguen siendo dinámicas.
==========================================================
*/

(function () {

    'use strict';

    console.log("[Helix V8.0 112] ATOM Modern UI iniciado…");


    //=========================================================
    // 1. CONFIGURACIÓN GENERAL
    //=========================================================

    const MODO_PARPADEO = "independiente";

    const CONFIG = {

        fondoEstados: true,

        fondoConBordes: false,

        hoverFilas: true,

        // La fila nunca tendrá animación.
        animaciones: false,

        efectosGlow: true,

        badges: true

    };


    const usuariosBlink = [

        "alejandro lozano morales",

        "juan luis tortola martinez",

        "sonia fernandez fernandez"

    ];


    //=========================================================
    // 2. CSS GLOBAL — ATOM MODERN UI
    //=========================================================

    const styleHelix = document.createElement("style");

    styleHelix.id = "Lx-Atom-Modern-Style";

    styleHelix.textContent = `

    /* =====================================================
       VARIABLES
       ===================================================== */

    :root {

        --lx-blue: #0078d4;

        --lx-blue-light: #4da3ff;

        --lx-green: #16823b;

        --lx-orange: #e67e00;

        --lx-red: #d00000;

        --lx-red-bright: #ff3030;

        --lx-violet: #6e42c1;

        --lx-shadow:
            0 2px 7px rgba(0,0,0,.14);

        --lx-shadow-hover:
            0 5px 15px rgba(0,0,0,.20);

    }


    /* =====================================================
       BLINK
       ===================================================== */

    @keyframes helixBlink {

        0%, 100% {

            opacity: 1;

            filter:
                brightness(1)
                saturate(1);

        }

        50% {

            opacity: .25;

            filter:
                brightness(1.45)
                saturate(1.25);

        }

    }


    .Lx-blink {

        animation:
            helixBlink
            1.2s
            ease-in-out
            12;

    }


    .Lx-noblink {

        animation: none !important;

    }


    /* =====================================================
       GLOW ROJO
       ===================================================== */

    @keyframes LxGlowRed {

        0%, 100% {

            box-shadow:
                0 0 3px
                rgba(255,0,0,.20);

        }

        50% {

            box-shadow:
                0 0 13px
                rgba(255,0,0,.70);

        }

    }


    /* =====================================================
       GLOW AZUL
       ===================================================== */

    @keyframes LxGlowBlue {

        0%, 100% {

            box-shadow:
                0 0 2px
                rgba(0,120,212,.15);

        }

        50% {

            box-shadow:
                0 0 10px
                rgba(0,120,212,.40);

        }

    }


    /* =====================================================
       APARICIÓN
       ===================================================== */

    @keyframes LxRowAppear {

        from {

            opacity: 0;

            transform:
                translateY(4px);

        }

        to {

            opacity: 1;

            transform:
                translateY(0);

        }

    }


    /* =====================================================
       TABLA
       ===================================================== */

    table.BaseTable {

        border-collapse:
            separate !important;

        border-spacing:
            0 3px !important;

    }


    /* =====================================================
       FILAS — TOTALMENTE FIJAS
       ===================================================== */

    table.BaseTable tbody tr {

        /*
        =====================================================
        BLOQUEO TOTAL DE MOVIMIENTO DE LA FILA
        =====================================================
        */

        transform:
            none !important;

        animation:
            none !important;

        transition:
            none !important;

        filter:
            none !important;

        box-shadow:
            none !important;

        position:
            static !important;

        left:
            auto !important;

        right:
            auto !important;

        margin:
            0 !important;

    }


    /* =====================================================
       FILAS HOVER — SOLO COLOR
       ===================================================== */

    table.BaseTable tbody tr:hover {

        transform:
            none !important;

        animation:
            none !important;

        transition:
            none !important;

        filter:
            none !important;

        box-shadow:
            none !important;

        position:
            static !important;

        left:
            auto !important;

        right:
            auto !important;

        margin:
            0 !important;

    }


    /* =====================================================
       CELDAS
       ===================================================== */

    table.BaseTable tbody tr td {

        transition:

            background-color
            .35s
            ease,

            color
            .35s
            ease,

            border-color
            .35s
            ease,

            box-shadow
            .35s
            ease;

        border-top:
            1px solid transparent;

        border-bottom:
            1px solid transparent;

    }


    /* =====================================================
       FILAS ALTERNAS
       ===================================================== */

    table.BaseTable tbody tr:nth-child(even) td {

        background-color:
            rgba(0,0,0,.018);

    }


    /* =====================================================
       HOVER DE FILA

       IMPORTANTE:
       SOLO cambia el color.

       NO:
       - padding
       - transform
       - border
       - margin
       - posición
       ===================================================== */

    table.BaseTable tbody tr:hover td {

        background-color:
            rgba(0,120,212,.055) !important;

    }


    /* =====================================================
       PRIMERA COLUMNA

       NO MODIFICAMOS PADDING.
       NO MODIFICAMOS BORDER.
       NO MODIFICAMOS POSICIÓN.
       ===================================================== */

    table.BaseTable tbody tr td:first-child {

        transition:
            background-color
            .35s
            ease,

            color
            .35s
            ease;

    }


    table.BaseTable tbody tr:hover td:first-child {

        padding-left:
            initial !important;

        transform:
            none !important;

        margin:
            0 !important;

        left:
            auto !important;

        right:
            auto !important;

    }


    /* =====================================================
       SPANS / PALABRAS
       ===================================================== */

    table.BaseTable td span {

        transition:

            color
            .30s
            ease,

            background-color
            .30s
            ease,

            box-shadow
            .30s
            ease,

            transform
            .20s
            ease,

            filter
            .30s
            ease;

    }


    /* =====================================================
       HOVER DE PALABRA

       Aquí sí permitimos pequeño efecto.
       La FILA no se mueve.
       ===================================================== */

    table.BaseTable td span:hover {

        transform:
            scale(1.03);

        filter:
            brightness(1.10);

        box-shadow:
            0 2px 7px
            rgba(0,0,0,.18);

    }


    /* =====================================================
       BADGES
       ===================================================== */

    .Lx-badge {

        display:
            inline-block;

        padding:
            3px 8px;

        border-radius:
            999px;

        font-size:
            11px;

        font-weight:
            700;

        letter-spacing:
            .2px;

        transition:

            transform
            .20s
            ease,

            box-shadow
            .25s
            ease,

            filter
            .25s
            ease;

    }


    .Lx-badge:hover {

        transform:
            scale(1.06);

        box-shadow:
            0 3px 9px
            rgba(0,0,0,.20);

        filter:
            brightness(1.08);

    }


    /* =====================================================
       ASSIGNED
       ===================================================== */

    table.BaseTable td
    span[data-estado="Assigned"] {

        background:
            linear-gradient(
                135deg,
                #ff453a,
                #d70015
            ) !important;

        color:
            white !important;

        padding:
            3px 9px !important;

        border-radius:
            7px !important;

        font-weight:
            800;

        letter-spacing:
            .2px;

        box-shadow:
            0 0 6px
            rgba(255,0,0,.35),

            inset 0 1px 0
            rgba(255,255,255,.30);

    }


    /* =====================================================
       HIGH
       ===================================================== */

    table.BaseTable td
    span[data-estado="High"] {

        color:
            #c00000 !important;

        font-weight:
            800;

        text-shadow:
            0 0 5px
            rgba(255,0,0,.18);

    }


    /* =====================================================
       BLINK HIGH
       ===================================================== */

    .Lx-blink[data-estado="High"] {

        animation:

            helixBlink
            1.2s
            ease-in-out
            12,

            LxGlowRed
            1.2s
            ease-in-out
            12;

    }


    /* =====================================================
       BLINK ASSIGNED
       ===================================================== */

    .Lx-blink[data-estado="Assigned"] {

        animation:

            helixBlink
            1.2s
            ease-in-out
            12,

            LxGlowRed
            1.2s
            ease-in-out
            12;

    }


    /* =====================================================
       FECHAS
       ===================================================== */

    table.BaseTable td[data-fecha-color="green"] {

        color:
            #16823b !important;

        font-weight:
            600;

        text-shadow:
            0 0 5px
            rgba(0,180,70,.18);

    }


    table.BaseTable td[data-fecha-color="orange"] {

        color:
            #e67e00 !important;

        font-weight:
            700;

        text-shadow:
            0 0 5px
            rgba(255,150,0,.20);

    }


    table.BaseTable td[data-fecha-color="red"] {

        color:
            #d00000 !important;

        font-weight:
            700;

        text-shadow:
            0 0 6px
            rgba(255,0,0,.20);

    }


    /* =====================================================
       FECHA HOVER
       ===================================================== */

    table.BaseTable td[data-fecha-color] {

        transition:

            color
            .35s
            ease,

            text-shadow
            .35s
            ease,

            background-color
            .35s
            ease;

    }


    table.BaseTable td[data-fecha-color="green"]:hover {

        background:
            rgba(0,180,70,.06) !important;

    }


    table.BaseTable td[data-fecha-color="orange"]:hover {

        background:
            rgba(255,150,0,.07) !important;

    }


    table.BaseTable td[data-fecha-color="red"]:hover {

        background:
            rgba(255,0,0,.07) !important;

    }


    /* =====================================================
       CABECERA
       ===================================================== */

    table.BaseTable thead th {

        transition:

            background
            .30s
            ease,

            color
            .30s
            ease,

            box-shadow
            .30s
            ease;

    }


    table.BaseTable thead th:hover {

        background:
            linear-gradient(
                135deg,
                rgba(0,120,212,.12),
                rgba(0,180,255,.08)
            ) !important;

        box-shadow:
            inset 0 -2px 0
            var(--lx-blue);

    }


    /* =====================================================
       EFECTO DE CELDA
       ===================================================== */

    table.BaseTable tbody td:hover {

        box-shadow:
            inset 0 0 0 1px
            rgba(0,120,212,.10);

    }


    /* =====================================================
       SELECCIÓN
       ===================================================== */

    table.BaseTable td::selection {

        background:
            var(--lx-blue);

        color:
            white;

    }


    /* =====================================================
       FOCUS
       ===================================================== */

    table.BaseTable td:focus-within {

        outline:
            none;

        box-shadow:

            inset 0 0 0 2px
            rgba(0,120,212,.25),

            0 0 8px
            rgba(0,120,212,.15);

    }


    /* =====================================================
       NUEVO CONTENIDO
       ===================================================== */

    @keyframes LxNewContent {

        0% {

            background-color:
                rgba(0,120,212,.18);

        }

        100% {

            background-color:
                transparent;

        }

    }


    .Lx-new-content {

        animation:
            LxNewContent
            1.5s
            ease-out;

    }

    `;

    document.head.appendChild(styleHelix);


    //=========================================================
    // 3. RESALTADOS
    //=========================================================

    const resaltados = [

        //=====================================================
        // TECHNICIANS FUJI
        //=====================================================

        {
            texto: 'ALEJANDRO LOZANO MORALES',
            color: 'Orange'
        },

        {
            texto: 'OVIDIO PARRON MARTINEZ',
            color: 'Grey'
        },

        {
            texto: 'MARIA PILAR CARRILLO SENDER',
            color: 'Grey'
        },

        {
            texto: 'Next Text',
            color: 'Grey'
        },

        {
            texto: 'Next Text',
            color: 'Grey'
        },

        {
            texto: 'Next Text',
            color: 'Grey'
        },


        //=====================================================
        // TECHNICIANS T-SYSTEMS
        //=====================================================

        {
            texto: 'JUAN LUIS TORTOLA MARTINEZ',
            color: 'green'
        },

        {
            texto: 'MIGUEL ANGEL GUEMES ALONSO',
            color: '#4B0082'
        },

        {
            texto: 'ERIC RODRIGUEZ LUQUE',
            color: '#FF6D00'
        },

        {
            texto: 'JOAN CARLES MESTRE GUILLEN',
            color: '#00CED1'
        },

        {
            texto: 'EDIFICI CIUTAT DE LA JUSTICIA',
            color: 'green'
        },

        {
            texto: 'ANGEL ROIG LORENZO',
            color: 'blue'
        },

        {
            texto: 'FERNANDO JIMENEZ PORTILLO',
            color: 'Blue'
        },

        {
            texto: 'DANIEL ESPLUGAS SANCHEZ',
            color: 'red'
        },

        {
            texto: 'SONIA FERNANDEZ FERNANDEZ',
            color: '#007FFF'
        },


        //=====================================================
        // GROUPS
        //=====================================================

        {
            texto: 'X03_ARCONTE_GSV-N2',
            color: '#6e7bf0'
        },

        {
            texto: 'X03_ARCONTE_GSV-N3-MAQ',
            color: '#ffff00'
        },

        {
            texto: 'X03_ARCONTE_GSV-N3-ESPECIALISTES',
            color: 'Brown'
        },

        {
            texto: 'X03_ARCONTE_GSV-N3-SENYAL_INSTITUCIONAL',
            color: 'red'
        },


        //=====================================================
        // COMMON ENTRIES
        //=====================================================

        {
            texto: '[Desplegament d’ARCONTE pujada de versió de la',
            color: 'Brown'
        },

        {
            texto: '[FASE1]',
            color: 'Brown'
        },

        {
            texto: '[FASE2]',
            color: 'Brown'
        },

        {
            texto: 'Actualitzar Aplicació. 3h',
            color: 'Brown'
        },

        {
            texto: 'Marxa enrere',
            color: 'Brown'
        },

        {
            texto: 'Proves. 30min',
            color: 'Brown'
        },

        {
            texto: 'Proves. 1h',
            color: 'Brown'
        },

        {
            texto: 'Marxa enrere. 1h',
            color: 'Brown'
        },

        {
            texto: 'Realització de Backups. 30m',
            color: 'Brown'
        },

        {
            texto: 'Proves . 30m',
            color: 'Brown'
        },

        {
            texto: 'Revisio de Sales SALA DE VISTES - AUDITORIUM',
            color: 'red'
        },

        {
            texto: 'Revisio de Sales SALA DE VISTES ',
            color: 'red'
        },

        {
            texto: 'Incidència Arconte En un ',
            color: 'grey'
        },

        {
            texto: 'Incidència Arconte ',
            color: 'grey'
        },

        {
            texto: 'Incidència ',
            color: 'grey'
        },

        {
            texto: 'Alta Certificats Digitals SSL, Aplicació i Segell',
            color: 'Pink'
        },

        {
            texto: 'Scheduled For Approval',
            color: 'Brown'
        },

        {
            texto: 'Staged',
            color: 'Brown'
        },

        {
            texto: 'Scheduled',
            color: 'Brown'
        },

        {
            texto: 'Aplicació de l',
            color: 'Brown'
        },

        {
            texto: 'actualització. 2h',
            color: 'Brown'
        },

        {
            texto: 'proves. 30m',
            color: 'Brown'
        },

        {
            texto: 'marxa enrere. 1h',
            color: 'Brown'
        },

        {
            texto: 'Moviments entre videos',
            color: '#6e7bf0'
        },

        {
            texto: 'Petició Sessió en Passat',
            color: '#6e7bf0'
        },

        {
            texto: 'Validacions funcionals ARCONTE',
            color: 'Violet'
        },


        //=====================================================
        // STATUS
        //=====================================================

        {
            texto: 'Assigned',
            color: 'white',
            fondo: 'red'
        },

        {
            texto: 'In Progress',
            color: 'Green',
            fondo: '#ccffcc'
        },

        {
            texto: 'High',
            color: 'Red'
        },

        {
            texto: '2-High',
            color: 'Red'
        },

        {
            texto: 'Medium',
            color: 'Orange'
        },

        {
            texto: 'Low',
            color: 'Grey'
        },

        {
            texto: 'Reopen',
            color: 'black'
        },

        {
            texto: '3-Medium',
            color: 'Orange'
        },

        {
            texto: 'Pending',
            color: 'orange'
        },

        {
            texto: '4-Low',
            color: 'Grey'
        },


        //=====================================================
        // TYPES
        //=====================================================

        {
            texto: 'Work Order',
            color: 'Violet'
        },

        {
            texto: 'Incident',
            color: 'Grey'
        },

        {
            texto: 'WO0000',
            color: 'Violet'
        },

        {
            texto: 'TAS0000',
            color: 'Violet'
        },

        {
            texto: 'CRQ000',
            color: 'Violet'
        },

        {
            texto: 'INC0000',
            color: '#6e7bf0'
        },

        {
            texto: 'Change',
            color: 'Violet'
        },

        {
            texto: 'Task',
            color: 'Violet'
        }

    ];


    //=========================================================
    // 4. COLORES FECHA
    //=========================================================

    const coloresFecha = {

        reciente: "green",

        media: "orange",

        antigua: "red"

    };


    //=========================================================
    // 5. PARSE FECHA
    //=========================================================

    function parseFecha(text) {

        if (!text)
            return null;

        const m = text
            .trim()
            .match(
                /^(\d{2})\/(\d{2})\/(\d{4})[\s\u00A0]+(\d{1,2}):(\d{2})(?::(\d{2}))?/
            );

        if (!m)
            return null;

        const [
            ,
            d,
            mo,
            y,
            hh,
            mm,
            ss
        ] = m;

        const fecha = new Date(
            +y,
            +mo - 1,
            +d,
            +hh,
            +mm,
            ss ? +ss : 0
        );

        return isNaN(fecha.getTime())
            ? null
            : fecha;

    }


    //=========================================================
    // 6. FAVICON
    //=========================================================

    let faviconOriginal = null;

    let faviconRojo = null;

    let faviconParpadeando = false;

    let intervaloFavicon = null;


    function crearFaviconRojo() {

        const canvas =
            document.createElement("canvas");

        canvas.width = 32;

        canvas.height = 32;

        const ctx =
            canvas.getContext("2d");

        ctx.fillStyle = "#ff0000";

        ctx.beginPath();

        ctx.arc(
            16,
            16,
            14,
            0,
            2 * Math.PI
        );

        ctx.fill();

        return canvas.toDataURL(
            "image/png"
        );

    }


    function obtenerFaviconActual() {

        const link =
            document.querySelector(
                "link[rel*='icon']"
            );

        return link
            ? link.href
            : null;

    }


    function cambiarFavicon(url) {

        let link =
            document.querySelector(
                "link[rel*='icon']"
            );

        if (!link) {

            link =
                document.createElement("link");

            link.rel = "icon";

            document.head.appendChild(link);

        }

        link.href = url;

    }


    function hayAssigned() {

        const tabla =
            document.querySelector(
                "table.BaseTable"
            );

        if (!tabla)
            return false;

        return tabla
            .textContent
            .toLowerCase()
            .includes("assigned");

    }


    function activarParpadeoFavicon() {

        if (faviconParpadeando)
            return;

        faviconOriginal =
            obtenerFaviconActual();

        faviconRojo =
            crearFaviconRojo();

        faviconParpadeando = true;

        intervaloFavicon =
            setInterval(() => {

                const link =
                    document.querySelector(
                        "link[rel*='icon']"
                    );

                if (!link)
                    return;

                const actual =
                    link.href;

                cambiarFavicon(
                    actual === faviconRojo
                        ? faviconOriginal
                        : faviconRojo
                );

            }, 1000);

    }


    function desactivarParpadeoFavicon() {

        if (!faviconParpadeando)
            return;

        clearInterval(
            intervaloFavicon
        );

        faviconParpadeando = false;

        cambiarFavicon(
            faviconOriginal
        );

    }


    //=========================================================
    // 7. COLOREAR CELDA
    //=========================================================

    function colorearTD(td) {

        if (!td)
            return;


        const textoOriginal =
            td.textContent.trim();


        //=====================================================
        // RESALTADOS
        //=====================================================

        if (
            td.dataset.lxProcesado !== "1"
        ) {

            let html =
                td.innerHTML;


            resaltados.forEach(r => {

                const safe =
                    r.texto.replace(
                        /[.*+?^${}()|[\]\\]/g,
                        '\\$&'
                    );


                const reg =
                    new RegExp(
                        `(${safe})`,
                        "gi"
                    );


                html =
                    html.replace(
                        reg,
                        match => {

                            let estilos = `

                                color:${r.color};

                                white-space:nowrap;

                                transition:
                                    all .3s ease;

                            `;


                            if (
                                CONFIG.fondoEstados &&
                                r.fondo
                            ) {

                                estilos += `

                                    background:
                                        ${r.fondo};

                                    box-decoration-break:
                                        clone;

                                    -webkit-box-decoration-break:
                                        clone;

                                    padding:
                                        3px 7px;

                                    border-radius:
                                        6px;

                                    line-height:
                                        1.15;

                                    font-weight:
                                        600;

                                    box-shadow:
                                        0 1px 4px
                                        rgba(0,0,0,.15);

                                `;

                            }


                            const lower =
                                match
                                    .trim()
                                    .toLowerCase();


                            let clases =
                                "Lx-noblink";


                            let extraAttr =
                                "";


                            //=================================
                            // ASSIGNED
                            //=================================

                            if (
                                lower ===
                                "assigned"
                            ) {

                                extraAttr +=
                                    ' data-estado="Assigned" ';

                            }


                            //=================================
                            // HIGH
                            //=================================

                            if (
                                lower === "high"
                            ) {

                                extraAttr +=
                                    ' data-estado="High" ';

                            }


                            //=================================
                            // MODO PARPADEO
                            //=================================

                            if (
                                MODO_PARPADEO ===
                                "constante"
                            ) {

                                clases =
                                    "Lx-blink";

                            }


                            else if (
                                MODO_PARPADEO ===
                                "intermitente"
                            ) {

                                clases =
                                    "Lx-blink";

                            }


                            else if (
                                MODO_PARPADEO ===
                                "independiente"
                            ) {

                                if (
                                    [
                                        "assigned",
                                        "in progress"
                                    ].includes(
                                        lower
                                    )
                                ) {

                                    clases =
                                        "Lx-blink";

                                }


                                if (
                                    usuariosBlink
                                        .includes(
                                            lower
                                        )
                                ) {

                                    clases =
                                        "Lx-blink";

                                }


                                if (
                                    lower ===
                                    "high"
                                ) {

                                    clases =
                                        "Lx-blink";

                                }

                            }


                            //=================================
                            // BADGES
                            //=================================

                            const badgeClass =
                                CONFIG.badges &&
                                [
                                    "assigned",
                                    "in progress",
                                    "high",
                                    "2-high",
                                    "medium",
                                    "low",
                                    "pending",
                                    "reopen",
                                    "3-medium",
                                    "4-low"
                                ].includes(lower)
                                    ? " Lx-badge"
                                    : "";


                            return `
                                <span
                                    class="${clases}${badgeClass}"
                                    style="${estilos}"
                                    ${extraAttr}
                                >
                                    ${match}
                                </span>
                            `;

                        }
                    );

            });


            td.innerHTML =
                html;

            td.dataset.lxProcesado =
                "1";

        }


        //=====================================================
        // FECHA DINÁMICA
        //=====================================================

        try {

            const fecha =
                parseFecha(
                    textoOriginal
                );


            if (fecha) {

                const ahora =
                    new Date();


                const diffHoras =
                    (
                        ahora - fecha
                    )
                    /
                    (
                        1000 *
                        60 *
                        60
                    );


                let colorFecha =
                    coloresFecha.reciente;


                let fechaTipo =
                    "green";


                if (
                    diffHoras > 24 &&
                    diffHoras <= 72
                ) {

                    colorFecha =
                        coloresFecha.media;

                    fechaTipo =
                        "orange";

                }


                else if (
                    diffHoras > 72
                ) {

                    colorFecha =
                        coloresFecha.antigua;

                    fechaTipo =
                        "red";

                }


                td.style.setProperty(
                    "color",
                    colorFecha,
                    "important"
                );


                td.dataset.fechaColor =
                    fechaTipo;

            }


        }

        catch (e) {

            console.warn(
                "[Helix] Error coloreando fecha:",
                textoOriginal,
                e
            );

        }


        //=====================================================
        // FAVICON
        //=====================================================

        setTimeout(() => {

            if (hayAssigned()) {

                activarParpadeoFavicon();

            }

            else {

                desactivarParpadeoFavicon();

            }

        }, 50);

    }


    //=========================================================
    // 8. COLOREAR TABLA
    //=========================================================

    function colorearTabla() {

        const tabla =
            document.querySelector(
                "table.BaseTable"
            );


        if (!tabla)
            return;


        tabla
            .querySelectorAll(
                "tbody tr td"
            )
            .forEach(td => {

                try {

                    colorearTD(td);

                }

                catch (e) {

                    console.warn(
                        "[Helix] Error procesando celda:",
                        e
                    );

                }

            });

    }


    //=========================================================
    // 9. INTERMITENCIA CONTROLADA
    //=========================================================

    if (
        MODO_PARPADEO ===
        "intermitente"
        ||
        MODO_PARPADEO ===
        "independiente"
    ) {

        setInterval(() => {

            const elementos =
                document.querySelectorAll(
                    ".Lx-blink"
                );


            if (
                !elementos.length
            )
                return;


            elementos.forEach(el => {

                el.classList.remove(
                    "Lx-blink"
                );

            });


            void document.body
                .offsetWidth;


            elementos.forEach(el => {

                el.classList.add(
                    "Lx-blink"
                );

            });

        }, 90000);

    }


    //=========================================================
    // 10. OBSERVER INTELIGENTE
    //=========================================================

    let observerActivo = null;

    let tablaActual = null;

    let pendiente = false;


    function debouncedColor() {

        if (pendiente)
            return;


        pendiente = true;


        setTimeout(() => {

            pendiente = false;

            colorearTabla();

        }, 120);

    }


    function engancharObserver(tabla) {

        if (observerActivo) {

            observerActivo.disconnect();

            observerActivo = null;

        }


        observerActivo =
            new MutationObserver(
                () => {

                    debouncedColor();

                }
            );


        if (
            tabla.parentElement
        ) {

            observerActivo.observe(
                tabla.parentElement,
                {
                    childList: true,
                    subtree: true
                }
            );

        }


        tablaActual =
            tabla;

    }


    function vigilarTabla() {

        const tabla =
            document.querySelector(
                "table.BaseTable"
            );


        if (!tabla) {

            setTimeout(
                vigilarTabla,
                500
            );

            return;

        }


        if (
            tabla !==
            tablaActual
        ) {

            console.log(
                "[Helix] Nueva tabla detectada → observer"
            );


            engancharObserver(
                tabla
            );


            colorearTabla();

        }


        setTimeout(
            vigilarTabla,
            2000
        );

    }


    //=========================================================
    // 11. RECÁLCULO DE FECHAS
    //=========================================================

    setInterval(
        colorearTabla,
        60000
    );


    //=========================================================
    // 12. ARRANQUE
    //=========================================================

    vigilarTabla();


    console.log(
        "[Helix V8.0 112] ATOM Modern UI activo ✓"
    );

})();
