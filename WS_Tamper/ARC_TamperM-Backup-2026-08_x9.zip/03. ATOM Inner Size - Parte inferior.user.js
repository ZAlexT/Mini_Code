// ==UserScript==
// @name         03. ATOM Inner Size - Parte inferior
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Ajusta el ancho del marco inferior de ATOM
// @match        https://atomgencat.onbmc.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // =========================================================
    // CONFIGURACIÓN
    // =========================================================

    // Ancho deseado
    const ANCHO = 700;

    // =========================================================
    // APLICAR TAMAÑO
    // =========================================================

    function aplicarTamano() {

        // PageHolder principal
        const pageHolder = document.querySelector('#WIN_3_304255200');

        if (!pageHolder) {
            return false;
        }

        // Forzar ancho principal
        pageHolder.style.width = `${ANCHO}px`;


        // Contenedor interior
        const fixedCH = pageHolder.querySelector(
            '.PageHolderStackViewFixedCH'
        );

        if (fixedCH) {
            fixedCH.style.width = `${ANCHO}px`;
        }


        // Fieldset exterior
        const fieldsetVertical = pageHolder.closest(
            'fieldset.PageBodyVertical'
        );

        if (fieldsetVertical) {
            fieldsetVertical.style.width = `${ANCHO}px`;
        }


        // Panel interno
        const panel = pageHolder.querySelector(
            '.StackPanel[arid="304255210"]'
        );

        if (panel) {

            panel.setAttribute('arinitsize', ANCHO);
            panel.setAttribute('arminsize', ANCHO);
            panel.setAttribute('armaxsize', ANCHO);

        }


        // Fieldset interno
        const fieldsetHorizontal = pageHolder.querySelector(
            'fieldset.PageBodyHorizontal'
        );

        if (fieldsetHorizontal) {
            fieldsetHorizontal.style.width = `${ANCHO}px`;
        }


        console.log(
            `[ATOM Size] Parte inferior ajustada a ${ANCHO}px`
        );

        return true;
    }


    // =========================================================
    // ESPERAR A QUE HELIX CARGUE EL ELEMENTO
    // =========================================================

    const intervalo = setInterval(() => {

        if (aplicarTamano()) {

            clearInterval(intervalo);

        }

    }, 500);


    // =========================================================
    // REAPLICAR SI HELIX MODIFICA EL TAMAÑO
    // =========================================================

    setInterval(() => {

        const pageHolder =
            document.querySelector('#WIN_3_304255200');

        if (!pageHolder) {
            return;
        }

        if (pageHolder.style.width !== `${ANCHO}px`) {

            aplicarTamano();

        }

    }, 1000);

})();