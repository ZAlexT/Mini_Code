// ==UserScript==
// @name         TEST - ATOM Request ID Regex
// @namespace    http://tampermonkey.net/
// @version      0.2
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const patrones = [
        { regex: /^INC\d+$/i, color: '#6e7bf0' },
        { regex: /^WO\d+$/i,  color: 'Violet' },
        { regex: /^TAS\d+$/i, color: 'Violet' },
        { regex: /^CRQ\d+$/i, color: 'Violet' }
    ];

    function procesar() {

        document.querySelectorAll(
            '.TableInner table span'
        ).forEach(span => {

            if (span.dataset.requestIdProcesado) return;

            const text = span.textContent.trim();

            for (const item of patrones) {

                if (item.regex.test(text)) {

                    span.style.color = item.color;
                    span.dataset.requestIdProcesado = '1';

                    break;
                }
            }
        });
    }

    const observer = new MutationObserver(() => {
        procesar();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    procesar();

})();