// ==UserScript==
// @name         04. ATOM Inner PopUp | V 0.1 | 001
// @namespace    http://tampermonkey.net/
// @version      0.1
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function aplicarCharcoal() {

        const textareas = document.querySelectorAll(".DIVPopup textarea");

        textareas.forEach(ta => {
            ta.style.setProperty("background-color", "#2b2b2b", "important");
            ta.style.setProperty("color", "white", "important");


        });
    }

    aplicarCharcoal();

    const observer = new MutationObserver(() => {
        aplicarCharcoal();
    });

    observer.observe(document.body, { childList: true, subtree: true });


(function () {
    'use strict';

    function setCharcoal(root = document) {
        root.querySelectorAll(
            'div[ardbn="z1D_WorkInfoToolTip_Info"] textarea.text[readonly]'
        ).forEach(t => {
            t.style.setProperty(
                'background-color',
                '#2b2b2b',
                'important'
            );
            t.style.color = '#e0e0e0';
        });
    }

    // inicial
    setCharcoal();



const style = document.createElement("style");
style.textContent = `
   // -----------------------------------------------
   // Full Window Frame
   //-----------------------------------------------

      // .DIVPopup,
      // .DIVPopup *,
      // .DIVPopupBody,

    .DIVPopupBody * {
        background-color: #2b2b2b !important;
    }
`;
document.head.appendChild(style);


    // dinámico (Helix redibuja)
    const obs = new MutationObserver(muts => {
        muts.forEach(m => {
            m.addedNodes.forEach(n => {
                if (n.nodeType === 1) setCharcoal(n);
            });
        });
    });

    obs.observe(document.body, { childList: true, subtree: true });
})();

// ==============================
// ⛳ CHARCOAL POPUP BACKGROUND
// ==============================
    const stylePopupOverride = document.createElement("style");
    stylePopupOverride.textContent = `
    textarea[id^="arid_WIN_"][class*="text"] {
        background-color: #2b2b2b !important;
        color: #e0e0e0 !important;
    }
`;
document.head.appendChild(stylePopupOverride);


})();