// ==UserScript==
// @name         03. ATOM Inner | V 0.8 - Colorear Textos
// @namespace    http://tampermonkey.net/
// @version      0.8
// @description  Coloreado dinámico de texto en Inner ATOM (Type, Notes, Submitter, Files) + fechas según antigüedad
// @author       AL
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

/*
==========================================================
  03. Helix ATOM Inner | Colorear Textos | V 0.8
==========================================================

DESCRIPCIÓN:
Este UserScript colorea dinámicamente el texto de las columnas
de la tabla interna "Inner ATOM" dentro de los tickets ATOM.
Soporta:
- Textos exactos en Type, Notes, Submitter y Files
- Textos parciales mediante Includes especiales
- Fechas con colores según antigüedad:
    • reciente (<24h) → verde
    • media (24-72h) → naranja
    • antigua (>72h) → rojo

INDICE DE BLOQUES PRINCIPALES:

1️⃣ CONSTANTES DE COLOREADO
   • typeColors       → colores exactos en columna Type
   • notesColors      → colores exactos en columna Notes
   • notesIncludes    → colores para textos parciales en Notes
   • submitterColors  → colores exactos en Submitter
   • submitterIncludes→ colores para textos parciales en submitter
   • filesColors      → colores exactos en Files
   • coloresFecha     → colores para fechas recientes/media/antigua
   • parseFecha(text) → parsea texto "dd/mm/yyyy hh:mm:ss" a objeto Date

2️⃣ FUNCIONES AUXILIARES
   • colorSpan(span, color) → Aplica color y peso de fuente
   • scanSpans(root=document) → Escanea spans visibles y aplica reglas:
       – Exactos primero
       – Includes especiales
       – Coloreado de fechas

3️⃣ ESCANEO INICIAL
   • scanSpans() → Se ejecuta al cargar la página

4️⃣ OBSERVER DINÁMICO
   • MutationObserver → Reaplica colores automáticamente a nodos nuevos

NOTAS:
- Cada span procesado se colorea según texto
- Includes permiten manejar identificadores parciales como "X03_ARCONTE_GSV"
- Compatible con Vivaldi y Edge
==========================================================
*/

(function() {
    'use strict';

    // ====================================================
    // 1️⃣ BLOQUE: CONSTANTES DE COLOREADO
    // ====================================================
    const typeColors = {
        "General Information": 		"grey",
        "Customer Communication": 	"yellow",
        "Data Acordada": 			"red",
        "Request Information": 		"orange",
        "Email User": 				"orange",
        "Company Assignment": 		"blue",
        "Resolution": 				"green"
    };

    const notesColors = {
        "This ticket was created from the service request system.": 	"yellow",
        "integracioCRM_ES_B4": 								"grey",
        "Assignat a : ESB4-N4-SUPORT PRESENCIAL": 				"grey",
        "Status has been changed to In Progress": 				"teal",
        "Status has been changed to Resolved": 					"green",
        "Assignat a : ES_B4_UTE T-SYSTEMS - INDRA: Text": 		"grey",
        "AM09_23 - DATA": 										"brown",
        "Resol. - ": 											"green",
        "Status has been changed to Completed": 				"green",
        "Confirmat tancament amb l’usuari.": 					"green",
        "Status has been changed to Closed": 					"green"
    };

    // 1️⃣a) Includes especiales para coincidencias parciales
    const notesIncludes = {
        "X03_ARCONTE_GSV": "#6e7bf0",
        "ES_B4_UTE T-SYSTEMS": "grey"
    };

    const submitterColors = {
        "46725918S": 					"orange",
        "DNI / NIF de Juan Luis - ET MICasaTeléfono": 		"yellow",
        "DNI / NIF Aquí": 				"yellow",
        "Remedy Application Service": 	"grey",
        "AR_ESCALATOR": 				"grey",
        "integracioitsm_AM09_23": 		"brown",
        "AM09_23 - DATA": 				"brown"
    };

    // 1️⃣b) Includes especiales para Submitter (coincidencias parciales)
    const submitterIncludes = {
        "AM09": "brown"   // cualquier texto que contenga "AM09" se coloreará de marrón
};

    const filesColors = {
        "0": "grey",
        "1": "red",
        "2": "red",
        "3": "red",
        "4": "red",
        "5": "red"
    };

    // 🔹 Colores para fechas
    const coloresFecha = {
        reciente : "green",
        media    : "orange",
        antigua  : "red"
    };

    // 🔹 Función para parsear fecha
    function parseFecha(text) {
        if (!/^\d{2}\/\d{2}\/\d{4}/.test(text)) return null;
        const [f, h] = text.split(" ");
        const [d, m, y] = f.split("/").map(Number);
        const [hh, mm, ss] = h.split(":").map(Number);
        return new Date(y, m - 1, d, hh, mm, ss);
    }

    // ====================================================
    // 2️⃣ BLOQUE: FUNCIONES AUXILIARES
    // ====================================================
    function colorSpan(span, color) {
        span.style.color = color;
        span.style.fontWeight = "450"; // peso de fuente ligero-firme
    }

    function scanSpans(root=document) {
        root.querySelectorAll("span").forEach(span=>{
            const text = span.textContent.trim();

            // 2️⃣a) Type exacto
            if(typeColors[text]) colorSpan(span, typeColors[text]);

            // 2️⃣b) Notes exacto
            if(notesColors[text]) colorSpan(span, notesColors[text]);

            // 2️⃣c) Notes especiales por Include
            for (const key in notesIncludes) {
                if(text.includes(key)) {
                    colorSpan(span, notesIncludes[key]);
                    break;
            // 2️⃣d1) Submitter especiales por Include
            for (const key in submitterIncludes) {
                if(text.includes(key)) {
                    colorSpan(span, submitterIncludes[key]);
                    break; // solo aplica el primero que coincida
    }
}

                }
            }

            // 2️⃣d) Submitter exacto
            if(submitterColors[text]) colorSpan(span, submitterColors[text]);

            // 2️⃣e) Files exacto
            if(filesColors[text]) colorSpan(span, filesColors[text]);

            // 2️⃣f) Colorear fechas
            const fecha = parseFecha(text);
            if (fecha) {
                const ahora = new Date();
                const diffHoras = (ahora - fecha) / (1000 * 60 * 60);
                let colorFecha = coloresFecha.reciente;

                if (diffHoras > 24 && diffHoras <= 72) colorFecha = coloresFecha.media;
                else if (diffHoras > 72) colorFecha = coloresFecha.antigua;

                colorSpan(span, colorFecha);
            }
        });
    }

    // ====================================================
    // 3️⃣ BLOQUE: ESCANEO INICIAL
    // ====================================================
    scanSpans();

    // ====================================================
    // 4️⃣ BLOQUE: OBSERVER DINÁMICO
    // ====================================================
    const observer = new MutationObserver(mutations=>{
        mutations.forEach(m=>{
            m.addedNodes.forEach(node=>{
                if(node.nodeType===1) scanSpans(node);
            });
        });
    });

    observer.observe(document.body, { childList:true, subtree:true });

})();