// ==UserScript==
// @name         02. ATOM Tooltip - Remove Background | V1.0.005
// @namespace    http://tampermonkey.net/
// @version      1.0.005
// @description  ATOM | Tooltip Backgrounds
// @match        https://atomgencat.onbmc.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
        // =============================================================
    // BARRERA PREVENTIVA DE FONDOS TOOLTIP
    // =============================================================

    const styleTooltipBlock =
        document.createElement('style');

    styleTooltipBlock.id =
        'ATOM-Tooltip-Background-Block';

    styleTooltipBlock.textContent = `
        [style*="SmallTooltip3.png"],
        [style*="WorkOrderSubmitterTooltip.png"] {
            background-image: none !important;
        }
    `;

    document.head.appendChild(styleTooltipBlock);


    console.log('[ATOM Tooltip] 1.0.005 iniciado');


    // =============================================================
    // 1. TOOLTIP ANTERIOR
    //
    // Mantener aquí el tratamiento del tooltip que ya funcionaba.
    // =============================================================

    function modificarTooltipAnterior() {

        document
            .querySelectorAll('div.divToolTipHtml')
            .forEach(tooltip => {

                const iframe =
                    tooltip.querySelector('iframe');

                if (!iframe)
                    return;

                try {

                    const doc =
                        iframe.contentDocument;

                    if (!doc || !doc.body)
                        return;


                    // -------------------------------------------------
                    // TOOLTIP ANTERIOR
                    //
                    // Aquí se mantiene su modificación.
                    // -------------------------------------------------

                    const fondoAnterior =
                        doc.querySelector(
                            'div[style*="SmallTooltip3.png"]'
                        );

                    if (!fondoAnterior)
                        return;

                    fondoAnterior.style.backgroundImage = 'none';
                    fondoAnterior.style.backgroundColor = '#252525';

                }

                catch (e) {

                    console.log(
                        '[ATOM Tooltip] Error tooltip anterior:',
                        e
                    );
                }
            });
    }


    // =============================================================
    // 2. WORK ORDER SUBMITTER TOOLTIP
    //
    // Tratamiento independiente.
    // =============================================================

    function modificarWorkOrderSubmitterTooltip() {

        document
            .querySelectorAll('div.divToolTipHtml')
            .forEach(tooltip => {

                const iframe =
                    tooltip.querySelector('iframe');

                if (!iframe)
                    return;

                try {

                    const doc =
                        iframe.contentDocument;

                    if (!doc || !doc.body)
                        return;


                    // -------------------------------------------------
                    // BUSCAR EXCLUSIVAMENTE
                    // WorkOrderSubmitterTooltip.png
                    // -------------------------------------------------

                    const elementos =
                        doc.querySelectorAll('*');

                    elementos.forEach(el => {

                        const estilo =
                            el.getAttribute('style') || '';

                        if (
                            !estilo.includes(
                                'WorkOrderSubmitterTooltip.png'
                            )
                        ) {
                            return;
                        }


                        console.log(
                            '[ATOM Tooltip] WorkOrderSubmitterTooltip encontrado:',
                            el
                        );


                        // Eliminar únicamente la imagen
                        el.style.backgroundImage = 'none';

                        // Nuevo fondo
                        el.style.backgroundColor = '#252525';

                    });

                }

                catch (e) {

                    console.log(
                        '[ATOM Tooltip] Error WorkOrderSubmitterTooltip:',
                        e
                    );
                }
            });
    }


    // =============================================================
    // 3. PROCESAMIENTO GLOBAL
    //
    // Cada tooltip se procesa por su propia función.
    // =============================================================

    function procesarTooltips() {

        modificarTooltipAnterior();

        modificarWorkOrderSubmitterTooltip();

    }


    // Primera ejecución
    procesarTooltips();


    // =============================================================
    // 4. OBSERVER
    // =============================================================

    const observer =
        new MutationObserver(() => {

            procesarTooltips();

        });

    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true
        }
    );


    // =============================================================
    // 5. COMPROBACIÓN PERIÓDICA
    // =============================================================

    setInterval(
        procesarTooltips,
        500
    );

})();